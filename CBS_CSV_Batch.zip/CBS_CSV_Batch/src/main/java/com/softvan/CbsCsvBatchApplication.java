package com.softvan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CbsCsvBatchApplication {


    public static void main(String[] args) {
        SpringApplication.run(CbsCsvBatchApplication.class, args);
    }
}
